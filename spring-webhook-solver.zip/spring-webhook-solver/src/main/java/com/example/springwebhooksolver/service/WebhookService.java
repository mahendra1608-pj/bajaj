package com.example.webhooksolver.service;

import com.example.webhooksolver.dto.GenerateWebhookRequest;
import com.example.webhooksolver.dto.GenerateWebhookResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Map;

@Service
public class WebhookService {

    private final RestTemplate restTemplate;

    @Value("${app.generate-webhook.url}")
    private String generateWebhookUrl;

    @Value("${app.test-webhook.url}")
    private String testWebhookUrl;

    @Value("${app.submitter.name}")
    private String submitterName;

    @Value("${app.submitter.regNo}")
    private String submitterRegNo;

    @Value("${app.submitter.email}")
    private String submitterEmail;

    @Value("${app.output.file}")
    private String outputFile;

    public WebhookService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        // small timeout safety
        this.restTemplate.setRequestFactory(
                new org.springframework.http.client.SimpleClientHttpRequestFactory() {{
                    setConnectTimeout((int) Duration.ofSeconds(20).toMillis());
                    setReadTimeout((int) Duration.ofSeconds(60).toMillis());
                }}
        );
    }

    public void executeFlowOnStartup() {
        try {
            System.out.println("Starting generateWebhook request...");
            GenerateWebhookRequest requestPayload = new GenerateWebhookRequest(submitterName, submitterRegNo, submitterEmail);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<GenerateWebhookRequest> reqEntity = new HttpEntity<>(requestPayload, headers);

            ResponseEntity<GenerateWebhookResponse> response =
                    restTemplate.exchange(generateWebhookUrl, HttpMethod.POST, reqEntity, GenerateWebhookResponse.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                String webhook = response.getBody().getWebhook();
                String accessToken = response.getBody().getAccessToken();

                System.out.println("Received webhook: " + webhook);
                System.out.println("Received accessToken: [REDACTED]");

                // Build final SQL (exactly the same provided above)
                String finalQuery = buildFinalQuery();

                // Save locally
                saveFinalQueryLocally(finalQuery);

                // Submit to the webhook
                submitFinalQueryToWebhook(webhook, accessToken, finalQuery);
            } else {
                System.err.println("generateWebhook request failed: " + response.getStatusCode());
            }
        } catch (Exception ex) {
            System.err.println("Exception during startup flow: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private String buildFinalQuery() {
        return """
            SELECT e.EMP_ID,
                   e.FIRST_NAME,
                   e.LAST_NAME,
                   d.DEPARTMENT_NAME,
                   (
                     SELECT COUNT(*)
                     FROM EMPLOYEE e2
                     WHERE e2.DEPARTMENT = e.DEPARTMENT
                       AND e2.DOB > e.DOB
                   ) AS YOUNGER_EMPLOYEES_COUNT
            FROM EMPLOYEE e
            JOIN DEPARTMENT d ON e.DEPARTMENT = d.DEPARTMENT_ID
            ORDER BY e.EMP_ID DESC;
            """;
    }

    private void saveFinalQueryLocally(String finalQuery) {
        try {
            Files.writeString(Path.of(outputFile), finalQuery);
            System.out.println("Saved final query to " + outputFile);
        } catch (Exception ex) {
            System.err.println("Failed to save final query locally: " + ex.getMessage());
        }
    }

    private void submitFinalQueryToWebhook(String webhookUrl, String accessToken, String finalQuery) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            // Use JWT token as provided. Many APIs expect "Bearer <token>" — use exactly what's required.
            // If they want raw token in Authorization header without Bearer, change accordingly.
            headers.set("Authorization", "Bearer " + accessToken);

            Map<String, String> payload = Map.of("finalQuery", finalQuery);

            HttpEntity<Map<String, String>> entity = new HttpEntity<>(payload, headers);
            System.out.println("Submitting finalQuery to webhook...");
            ResponseEntity<String> resp = restTemplate.postForEntity(webhookUrl, entity, String.class);

            System.out.println("Webhook submission response status: " + resp.getStatusCode());
            System.out.println("Webhook response body: " + resp.getBody());
        } catch (Exception ex) {
            System.err.println("Failed to submit finalQuery to webhook: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
