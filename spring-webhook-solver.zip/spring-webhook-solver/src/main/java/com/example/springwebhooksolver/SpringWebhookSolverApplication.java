package com.example.springwebhooksolver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebhookSolverApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringWebhookSolverApplication.class, args);
    }
}
