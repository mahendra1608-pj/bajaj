package com.example.webhooksolver.dto;

public record GenerateWebhookRequest(String name, String regNo, String email) {}
